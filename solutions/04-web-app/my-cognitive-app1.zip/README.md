# Overview

This app is used as base code for CASCON cognitive workshop.  It consumes the
[Text to Speech](02-text-to-speech/text-to-speech.md) and
[Personality Insights](03-personality-insights/personality-insights.md) APIs created in
[earlier](01-setup/setup.md) in this workshop.  In specific, this application invokes:

- https://<email-id>-cognitive-api1.mybluemix.net/api/t2s
- https://<email-id>-cognitive-api1.mybluemix.net/api/pi


## Setup & Test

The app can be run in local and remote mode.

### Remote mode

- Change the name of the application in `manifest.yml` before pushing the app to Bluemix.
  Edit `manifest.yml` and change the `name` and `host. 
- `cf login` to sign in to Bluemix
- `cf push` to deploy to Bluemix
- Once the application is deployed and running, launch the application URL to test the
  the application on Bluemix, `http://<email-id>-cognitive-app1.mybluemix.net/index.html`

### Local mode

- To see a JSON representation of your app's environment data, type `cf env APP_NAME` and Review
  the output.
- Locate `VCAP_SERVICES` and `VCAP_APPLICATION` in the output and copy the contents.
- Paste the copied contents in `config/development.json` under the appropriate section.  Review
  `config/development.json` to understand the structure and where to copy the appropriate
  cf env entries.
- Using nodemon or VS Code debugger, launch the application and test locally by launching
  application URL `http://localhost:600X/index.html` where X is the random port assigned
  by node runtime.



[comment]: # "------------------------------------------------------------------------------"
[comment]: # "                              Links / Reference                               "
[comment]: # "------------------------------------------------------------------------------"

[arc]: https://advancedrestclient.com/ "Advance REST Client"
[appgit]: git@github.ibm.com:CASCON/cas-cognitive-app1.git "Web App Source Code on Github"
