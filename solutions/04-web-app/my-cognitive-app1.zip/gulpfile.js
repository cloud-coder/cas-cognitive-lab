var gulp = require('gulp');
var wiredep = require('wiredep').stream;

gulp.task('default', function() {
  gulp.start('bower-dependencies')
});

gulp.task('bower-dependencies', function () {
  gulp.src('./public/index.html')
    .pipe(wiredep({
      directory: './public/bower_components',
      bowerJson: require('./bower.json'),
    }))
    .pipe(gulp.dest('./public/'));
});
