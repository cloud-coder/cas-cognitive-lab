// Lazy load angular app
angular.element(document).ready(function () {
  console.log("document.ready fired");
  angular.bootstrap(document, ["cas-cognitive-app1"]);
});
