(function (angular) {
  'use strict';
  // module name
  var thisModuleName = "cas-cognitive-app1.filters.percentage";

  angular.module(thisModuleName, [
    // include all dependencies for this module (i.e. models)
  ])
  // -------------------------------------------------------------------
  // Percentage Filter
  // -------------------------------------------------------------------
  .filter('percentage', ['$filter', function ($filter) {
    return function (input, decimals) {
      return $filter('number')(input * 100, decimals) + '%';
    };
  }]);

})(angular);
