(function (angular) {
  'use strict';
  // module name
  var thisModuleName = "cas-cognitive-app1.filters.trusted";

  angular.module(thisModuleName, [
    // include all dependencies for this module (i.e. models)
  ])
  // -------------------------------------------------------------------
  // Trusted Filter
  // -------------------------------------------------------------------
  .filter('trusted', ['$sce', function ($sce) {
    return function (url) {
      return $sce.trustAsResourceUrl(url);
    };
  }]);

})(angular);
