(function (angular) {
  'use strict';
  // module name
  var thisModuleName = "cas-cognitive-app1.controllers.speech";

  var appController = angular.module(thisModuleName, [
    // include all dependencies for this module (i.e. models)
    "cas-cognitive-app1.services.cognitive"
  ]);
  // -------------------------------------------------------------------
  // Speech Controller
  // -------------------------------------------------------------------
  appController.controller("SpeechCtrl", ["$scope", "$q", "$state", "$log", "$timeout", "cognitiveService",
    function ($scope, $q, $state, $log, $timeout, cognitiveService) {

      $log.debug("====== Entering SpeechCtrl");
      // -----------------------------------------------------------------------------
      // Initialize $scope & load models.  $scope variables can be accessed from template
      // -----------------------------------------------------------------------------
      $scope.data = {
        "text": "",
        "voice": "en-US_AllisonVoice",
        "serviceState": 0,
        "serviceErrorMessage": "",
        "soundData": null
      };

      // -----------------------------------------------------------------------------
      // Public methods that can be accessed from template
      // -----------------------------------------------------------------------------
      $scope.loadText = function () {
        if ($scope.data.text.length <= 0) {
          $log.debug("empty string.  please enter text");
          return;
        }
        // indicate that we are about to make the call
        $scope.data.serviceState = 1;
        cognitiveService.invokeText2Speech($scope.data.text, $scope.data.voice).then(
          function(res) {
            // show the watson animated icon for a bit longer :-)
            $timeout(function(){
              // indicate that we are about to make the call
              $scope.data.serviceState = 2;
              $scope.data.soundData = "data:audio/ogg;base64,"+res.data.base64_audio;
            }, 2000);
          },
          function(err) {
            // there was an error
            $scope.data.serviceErrorMessage= err;
            $scope.data.serviceState = 3;
          }
        );
      };

      // -----------------------------------------------------------------------------
      // Private methods
      // -----------------------------------------------------------------------------

      // -----------------------------------------------------------------------------
      // Execute code here that must run once as this controller initializes
      // -----------------------------------------------------------------------------
    }
  ]);
})(angular);
