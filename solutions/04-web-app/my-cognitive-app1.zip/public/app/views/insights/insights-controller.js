(function (angular) {
  'use strict';
  // module name
  var thisModuleName = "cas-cognitive-app1.controllers.insights";

  var appController = angular.module(thisModuleName, [
    // include all dependencies for this module (i.e. models)
    "cas-cognitive-app1.services.cognitive",
    "cas-cognitive-app1.services.twitter"
  ]);
  // -------------------------------------------------------------------
  // Personality Insights Controller
  // -------------------------------------------------------------------
  appController.controller("InsightsCtrl", ["$scope", "$q", "$state", "$log", "$timeout", "cognitiveService", "twitterService",
    function ($scope, $q, $state, $log, $timeout, cognitiveService, twitterService) {

      $log.debug("====== Entering InsightsCtrl");
      // -----------------------------------------------------------------------------
      // Initialize $scope & load models.  $scope variables can be accessed from template
      // -----------------------------------------------------------------------------
      $scope.data = {
        "text": "",
        "twitterScreenName": "",
        "piServiceState": 0,
        "twitterServiceState": 0,
        "serviceErrorMessage": "",
        "insightsData": null,
        "twitterFeeds": []
      };


      // -----------------------------------------------------------------------------
      // Public methods that can be accessed from template
      // -----------------------------------------------------------------------------
      $scope.getInsights = function () {
        if ($scope.data.text.length <= 0 &&
          $scope.data.twitterFeeds.length <= 0) {
          $log.debug("empty data.  please enter text");
          return;
        }
        // if either data.text or data.twitterFeeds is not empty
        // then make then invoke personality insight API
        // if both data.text and data.twitterFeeds are present,
        // combine the text and then invoke personality insight API
        console.log("$scope.data.text length: " + $scope.data.text.length);
        console.log("$scope.data.twitterFeeds length: " + $scope.data.twitterFeeds.length);
        var insightText = $scope.data.text + $scope.data.twitterFeeds;
        console.log("insightText length: " + insightText.length);

        // indicate that we are about to make the call
        $scope.data.piServiceState = 1;
        cognitiveService.invokeInsights(insightText).then(
          function(res) {
            // show the watson animated icon for a bit longer :-)
            $timeout(function(){
              // indicate that we are now done retrieving data
              $scope.data.piServiceState = 2;
              $scope.data.insightsData = res.data.big_5;
            }, 2000);
          },
          function(err) {
            // there was an error
            $scope.data.serviceErrorMessage= err;
            $scope.data.insightsData = null;
            $scope.data.piServiceState = 3;
          }
        );
      };
      $scope.getTwitterFeeds = function() {
        console.log("getTwitterFeeds for " + $scope.data.twitterScreenName);

        $scope.data.twitterServiceState = 1;
        $scope.data.piServiceState = 0; // hide PI results
        twitterService.getTimeline($scope.data.twitterScreenName).then(
          function(res) {
            $scope.data.twitterServiceState = 2;
            $scope.data.twitterFeeds = res.data;
          },
          function(err) {
            $scope.data.twitterServiceState = 3;
            $scope.data.twitterFeeds = [];
            $scope.data.serviceErrorMessage= err;
          }
        );

      };

      // -----------------------------------------------------------------------------
      // Private methods
      // -----------------------------------------------------------------------------

      // -----------------------------------------------------------------------------
      // Execute code here that must run once as this controller initializes
      // -----------------------------------------------------------------------------
    }
  ]);
})(angular);
