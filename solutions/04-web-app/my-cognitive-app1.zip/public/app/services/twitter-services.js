/**
 * This module defines services and data used by the application controllers.
 * The module provides a simple data structure containing menu items.
 *
 */
(function (angular) {

  // module name
  var thisModuleName = "cas-cognitive-app1.services.twitter";

  var appService = angular.module(thisModuleName, [
    // include all dependencies for this module (i.e. models)
  ]);
  //
  // Service: twitterService
  // Provides ?? methods
  //
  appService.factory("twitterService", ["$q", "$http", "$log", "apiBaseUrl",
    function ($q, $http, $log, apiBaseUrl) {
      $log.debug("====== Entering service twitterService");
      // -----------------------------------------------------------------------------
      // service data model
      // -----------------------------------------------------------------------------
      var theService = {};
      // -----------------------------------------------------------------------------
      // Private service variables and methods.  These are not accessible to callers
      // -----------------------------------------------------------------------------

      // -----------------------------------------------------------------------------
      // Public API variables and methods.  These are accessible to callers
      // -----------------------------------------------------------------------------
      theService.getTweets = function (screenName) {
        var def = $q.defer();

        var httpHeaders = {
          "Accept": "application/json"
        }
        var apiUrl = apiBaseUrl + "/api/twitter/tweets/" + screenName
        var httpOptions = {
          "method": "GET",
          "url": apiPath,
          "headers": httpHeaders
        };

        $log.debug("getTweets(): apiUrl: ", apiUrl);

        $http(httpOptions).then(
          // success
          function (res) {
            def.resolve(res);
          },
          // error
          function (err) {
            def.reject(err);
          }
        );
        return def.promise;
      };

      theService.getTimeline = function (screenName) {
        var def = $q.defer();

        var httpHeaders = {
          "Accept": "application/json"
        }
        var apiUrl = apiBaseUrl + "/api/twitter/timeline/" + screenName
        var httpOptions = {
          "method": "GET",
          "url": apiUrl,
          "headers": httpHeaders
        };

        $log.debug("getTimeline(): apiUrl: ", apiUrl);

        $http(httpOptions).then(
          // success
          function (res) {
            def.resolve(res);
          },
          // error
          function (err) {
            def.reject(err);
          }
        );
        return def.promise;
      };

      // -----------------------------------------------------------------------------
      // Execute code here that must run once as this service initializes
      // -----------------------------------------------------------------------------

      // -----------------------------------------------------------------------------
      // always return the service public API object
      // -----------------------------------------------------------------------------
      return theService;
    }
  ]);
})(angular);
