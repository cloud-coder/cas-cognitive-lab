/**
 * This module defines services and data used by the application controllers.
 * The module provides a simple data structure containing menu items.
 *
 */
(function (angular) {

  // module name
  var thisModuleName = "cas-cognitive-app1.services.cognitive";

  var appService = angular.module(thisModuleName, [
    // include all dependencies for this module (i.e. models)
  ]);
  //
  // Service: cognitiveService
  // Provides ?? methods
  //
  appService.factory("cognitiveService", ["$q", "$http", "$log", "apiBaseUrl",
    function ($q, $http, $log, apiBaseUrl) {
      $log.debug("====== Entering service cognitiveService");
      // -----------------------------------------------------------------------------
      // service data model
      // -----------------------------------------------------------------------------
      var theService = {};
      // -----------------------------------------------------------------------------
      // Private service variables and methods.  These are not accessible to callers
      // -----------------------------------------------------------------------------

      // -----------------------------------------------------------------------------
      // Public API variables and methods.  These are accessible to callers
      // -----------------------------------------------------------------------------
      theService.invokeText2Speech = function (textToSay, voice) {
        var def = $q.defer();

        var data = {
          "text": textToSay,
          "voice": voice
        };
        var httpHeaders = {
          "Content-type": "application/json"
        }
        var apiUrl = apiBaseUrl + "/api/t2s";
        var httpOptions = {
          "method": "POST",
          "url": apiUrl,
          "data": data,
          "headers": httpHeaders
        };

        $log.debug("invokeText2Speech(): apiUrl: ", apiUrl);
        $log.debug("invokeText2Speech(): data: ", data);

        $http(httpOptions).then(
          // success
          function (res) {
            def.resolve(res);
          },
          // error
          function (err) {
            def.reject(err);
          }
        );

        return def.promise;
      };
      theService.invokeInsights = function (textToAnalyse) {
        var def = $q.defer();

        var data = {
          "text": textToAnalyse
        };
        var httpHeaders = {
          "Content-type": "application/json"
        }
        var apiUrl = apiBaseUrl + "/api/pi";
        var httpOptions = {
          "method": "POST",
          "url": apiUrl,
          "data": data,
          "headers": httpHeaders
        };

        $log.debug("invokeInsights(): apiUrl: ", apiUrl);
        $log.debug("invokeInsights(): data: ", data);

        $http(httpOptions).then(
          // success
          function (res) {
            def.resolve(res);
          },
          // error
          function (err) {
            def.reject(err);
          }
        );

        return def.promise;
      };

      // -----------------------------------------------------------------------------
      // Execute code here that must run once as this service initializes
      // -----------------------------------------------------------------------------

      // -----------------------------------------------------------------------------
      // always return the service public API object
      // -----------------------------------------------------------------------------
      return theService;
    }
  ]);
})(angular);
