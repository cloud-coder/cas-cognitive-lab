/*eslint-env node*/

// =============================================================================
// BASE SETUP
// =============================================================================

// import modules
var express = require("express");
var app = express();

// bootstrap application settings
require("./helpers/express-init")(app);

// continue importing modules
var appEnvironment = require("./helpers/app-env");
var log = require("winston");

// =============================================================================
// START THE SERVER
// =============================================================================

// show some useful information about app Cloud Foundry environment
appEnvironment.showAppEnvironment();

// start server on the specified port and binding host
var appEnv = appEnvironment.getAppEnvironment();
var server = app.listen(appEnv.port, "0.0.0.0", function () {
  // print a message when the server starts listening
  log.info("server starting on " + appEnv.url);
});

// =============================================================================
// EXPORT THE SERVER
// =============================================================================

// export 'server' so that we can test it and invoke 'server.close()'
// 'app' object does not expose .close() method.  Only app.listen() returns
// a handle for .close().  It is crutial to invoke server.close() after
// gulp test execution is done to properly terminate gulp run.
exports = module.exports = server;
