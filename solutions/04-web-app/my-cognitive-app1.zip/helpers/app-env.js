'use strict';

//
// Module dependencies
//
var log = require('winston'),
  config = require('config'),
  cfenv = require('cfenv');

log.debug("setting up appEnvironment helper module");

//
// Private Variables & Functions
//
// build options for cfenv.  options parameter is only applicable in local mode
var appEnv = cfenv.getAppEnv();
if (appEnv.isLocal) {
  log.debug("reconfiguring appEnv for local mode");
  var cfEnvOptions = {
    vcap: {
      application: config.cfLocalEnv.VCAP_APPLICATION,
      services: config.cfLocalEnv.VCAP_SERVICES
    }
  };
  appEnv = cfenv.getAppEnv(cfEnvOptions);
}

//
// Module Exports
//
module.exports = {

  showAppEnvironment: function () {
    // display some data about the app environment
    log.info("app running mode:", appEnv.isLocal ? "Local" : "Bluemix");
  },

  getAppEnvironment: function () {
    // get the app environment from Cloud Foundry
    return appEnv;
  }
};
