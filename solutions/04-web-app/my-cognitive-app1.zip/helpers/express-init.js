'use strict';

//
// Module dependencies
//
var express = require("express"),
  config = require("config"),
  morgan = require("morgan"),
  cors = require("cors"),
  compression = require("compression"),
  helmet = require("helmet"),
  winston = require("winston"),
  fs = require("fs");

//
// Private Variables & Functions
//

// setup logging
winston.remove(winston.transports.Console);
winston.add(winston.transports.Console, {
  "colorize": config.logging.colorize_console
});
winston.level = config.logging.level;
var log = winston;

log.debug("bootstrapping express");

//
// Module Exports
//
module.exports = function (app) {

  // serve the files out of ./public as our main files
  app.use(express.static(__dirname + '/../public'));

  // HTTP logging
  var logStream = fs.createWriteStream("access.log", {"flags": "a"});
  app.use("/", morgan("combined", {"stream": logStream}));

  // enable request/response compression
  app.use(compression());

  // Enable API security
  if (config.security) {
    // CORS
    app.use(cors({
      "origin": "*",
      "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
      "allowedHeaders": ["Content-Type", "Authorization"]
    }));

    // armour our API with helmet security middleware to guard against
    // common HTTP/S attacks
    app.use(helmet());
  }

  log.debug("bootstrapping complete");
};
